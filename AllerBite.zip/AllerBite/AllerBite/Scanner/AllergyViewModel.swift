//
//  AllergyViewModel.swift
//  AllerBite
//
//  Created by Sahil Aggarwal on 09/10/24.
//

import Foundation
class AllergyViewModel: ObservableObject {
    @Published var selectedAllergies: Set<String> = []

    // Function to load saved allergies
    func loadSavedAllergies() {
        if let savedAllergies = UserDefaults.standard.array(forKey: "savedAllergies") as? [String] {
            print("Loaded saved allergies:", savedAllergies)
            self.selectedAllergies = Set(savedAllergies)
        }
    }
}
