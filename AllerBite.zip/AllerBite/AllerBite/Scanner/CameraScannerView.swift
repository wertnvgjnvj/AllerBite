import SwiftUI

struct CameraScanner: View {
    @Environment(\.presentationMode) var presentationMode
    var body: some View {
        NavigationView {
            Text("Scanning View")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button {
self.presentationMode.wrappedValue.dismiss()
                        } label: {
                              Text("Cancel")
                        }
                    }
                }
                .interactiveDismissDisabled(true)
        }
    }
}
//import SwiftUI
//
//struct CameraScanner: View {
//    @Environment(\.presentationMode) var presentationMode
//    @ObservedObject private var cameraCapture = CameraPhotoCapture() // Initialize CameraPhotoCapture
//
//    var body: some View {
//        NavigationView {
//            VStack {
//                // Display captured image if available
//                if let capturedImage = cameraCapture.capturedImage {
//                    Image(uiImage: capturedImage)
//                        .resizable()
//                        .scaledToFit()
//                        .frame(height: 300)
//                        .padding()
//                } else {
//                    Text("No image captured")
//                        .foregroundColor(.gray)
//                        .padding()
//                }
//                
//                Spacer()
//
//                // Button to capture the image
//                Button(action: {
//                    cameraCapture.captureScreenshot()
//                }) {
//                    Text("Capture Photo")
//                        .font(.headline)
//                        .foregroundColor(.white)
//                        .padding()
//                        .background(cameraCapture.isCapturingPhoto ? Color.gray : Color.blue)
//                        .cornerRadius(10)
//                }
//                .padding()
//                .disabled(cameraCapture.isCapturingPhoto) // Disable the button when photo is being captured
//                
//                Spacer()
//            }
//            .toolbar {
//                ToolbarItem(placement: .navigationBarLeading) {
//                    Button {
//                        self.presentationMode.wrappedValue.dismiss()
//                    } label: {
//                        Text("Cancel")
//                    }
//                }
//            }
//            .interactiveDismissDisabled(true) // Disable swipe to dismiss
//        }
//    }
//}
