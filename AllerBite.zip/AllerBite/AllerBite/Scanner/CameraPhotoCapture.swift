import Foundation
import AVFoundation
import UIKit

var delegate = MyDelegate()

class CameraPhotoCapture: ObservableObject {
    var captureSession: AVCaptureSession!
    var stillImageOutput: AVCapturePhotoOutput!
    @Published var capturedImage: UIImage?
    
    init(){ 
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = AVCaptureSession.Preset.hd1920x1080
        stillImageOutput = AVCapturePhotoOutput()
        
        if let device = AVCaptureDevice.default(for: .video) {
            do {
                let input = try AVCaptureDeviceInput(device: device)
                if (captureSession.canAddInput(input)) {
                    captureSession.addInput(input)
                    if (captureSession.canAddOutput(stillImageOutput)) {
                        captureSession.addOutput(stillImageOutput)
                        captureSession.startRunning()
                    }
                }
            } catch {
                print(error)
            }
        }
    }
    
    func captureScreenshot() {
        let settingsForMonitoring = AVCapturePhotoSettings()
        settingsForMonitoring.flashMode = .auto
        settingsForMonitoring.isAutoStillImageStabilizationEnabled = true
        settingsForMonitoring.isHighResolutionPhotoEnabled = false
        stillImageOutput?.capturePhoto(with: settingsForMonitoring, delegate: delegate)
    }
}

class MyDelegate : NSObject, AVCapturePhotoCaptureDelegate {
    func photoOutput(_ captureOutput: AVCapturePhotoOutput, didFinishProcessingPhoto photoSampleBuffer: CMSampleBuffer?, previewPhoto previewPhotoSampleBuffer: CMSampleBuffer?, resolvedSettings: AVCaptureResolvedPhotoSettings, bracketSettings: AVCaptureBracketedStillImageSettings?, error: Error?) {
        if let err = error{
            print(error)
        }
        if let photoSampleBuffer = photoSampleBuffer {
            if let photoData = AVCapturePhotoOutput.jpegPhotoDataRepresentation(forJPEGSampleBuffer: photoSampleBuffer, previewPhotoSampleBuffer: previewPhotoSampleBuffer) {
                do {
                    let url = try FileManager.default
                        .url(for: .documentDirectory,
                             in: .userDomainMask,
                             appropriateFor: nil,
                             create: true)
                        .appendingPathComponent("preview.jpeg")
                    try photoData.write(to: url)
                    
                } catch {
                    print(error.localizedDescription)
                }
            }
        }
    }
}

//
//import Foundation
//import AVFoundation
//import UIKit
//
//class CameraPhotoCapture: NSObject, ObservableObject { // Now inherits from NSObject
//    var captureSession: AVCaptureSession!
//    var stillImageOutput: AVCapturePhotoOutput!
//    @Published var capturedImage: UIImage?
//    @Published var isCapturingPhoto = false // Prevent multiple photo captures
//    
//    override init() { // Use override because it now inherits NSObject
//        super.init()
//        
//        captureSession = AVCaptureSession()
//        captureSession.sessionPreset = AVCaptureSession.Preset.hd1920x1080
//        stillImageOutput = AVCapturePhotoOutput()
//        
//        if let device = AVCaptureDevice.default(for: .video) {
//            do {
//                let input = try AVCaptureDeviceInput(device: device)
//                if (captureSession.canAddInput(input)) {
//                    captureSession.addInput(input)
//                    if (captureSession.canAddOutput(stillImageOutput)) {
//                        captureSession.addOutput(stillImageOutput)
//                        captureSession.startRunning()
//                    }
//                }
//            } catch {
//                print(error)
//            }
//        }
//    }
//    
//    func captureScreenshot() {
//        // Prevent multiple captures
//        guard !isCapturingPhoto else { return }
//        
//        isCapturingPhoto = true
//        
//        let settingsForMonitoring = AVCapturePhotoSettings()
//        settingsForMonitoring.flashMode = .auto
//        settingsForMonitoring.isAutoStillImageStabilizationEnabled = true
//        settingsForMonitoring.isHighResolutionPhotoEnabled = false
//        stillImageOutput?.capturePhoto(with: settingsForMonitoring, delegate: self) // Conform to delegate
//    }
//}
//
//// Extend CameraPhotoCapture to conform to the AVCapturePhotoCaptureDelegate
//extension CameraPhotoCapture: AVCapturePhotoCaptureDelegate {
//    func photoOutput(_ captureOutput: AVCapturePhotoOutput, didFinishProcessingPhoto photoSampleBuffer: CMSampleBuffer?, previewPhoto previewPhotoSampleBuffer: CMSampleBuffer?, resolvedSettings: AVCaptureResolvedPhotoSettings, bracketSettings: AVCaptureBracketedStillImageSettings?, error: Error?) {
//        if let err = error {
//            print("Error capturing photo: \(err)")
//            isCapturingPhoto = false
//            return
//        }
//        
//        if let photoSampleBuffer = photoSampleBuffer,
//           let photoData = AVCapturePhotoOutput.jpegPhotoDataRepresentation(forJPEGSampleBuffer: photoSampleBuffer, previewPhotoSampleBuffer: previewPhotoSampleBuffer) {
//            self.capturedImage = UIImage(data: photoData)
//        }
//
//        // Reset capturing flag after processing the photo
//        isCapturingPhoto = false
//    }
//}
