import SwiftUI
struct ContentView: View {
    @State private var showSplash = true
    @State private var selection = 0
    @State private var isSettingViewActive = false
    @State private var isMainViewActive = false
    @State var isActive: Bool = false
    @GestureState private var dragOffset: CGSize = .zero
    @State private var selectedTab = 0
    @State private var isSheetVisible = false
    @State private var userName: String = ""
    
    var body: some View {
        GeometryReader { geometry in
            NavigationView {
                ZStack {
                    ScrollView {
                        VStack {
                            ArtWork()
                        }
                        
                        Spacer() // Push the TabView to the bottom of the screen
                    }
                    
                    // Bottom View with Buttons
                    VStack {
                        // Bottom Bar with Glass Morphism Effect
                        ZStack {
                            // Background color with opacity
                            Color.clear // Use clear color to make it invisible
                            
                            // Blur effect
                            VisualEffectView(effect: UIBlurEffect(style: .systemMaterial))
                                .opacity(0.5) // Adjust opacity of the blur effect
                            
                            // Bottom bar content
                            Rectangle()
                                .fill(LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.3), Color.white.opacity(0.0)]), startPoint: .top, endPoint: .bottom))
                                .frame(height: 120)
                        }
                        .frame(height: 80)
                        .offset(y: 40)
                    }
                    
                    TabView(selection: $selection) {
                        // Home Tab
                        
                        HomeView(userName: "Aditya Gaba")
                            .offset(y:0)
                            .tabItem {
                                CustomTabItem(imageName: "house.fill", text: "Home")
                                
                            }
                            .tag(0)
                        
                        // Scanner Tab
                        
                        BarcodeTextScannerView()
                        
                            .tabItem {
                                CustomTabItem(imageName: "barcode.viewfinder", text: "Scanner")
                                
                            }
                            .tag(1)
                        
                        // Browse Tab
                        HealthPlannerContentView()
                            .tabItem {
                                CustomTabItem(imageName: "square.grid.2x2.fill", text: "Browse")
                            }
                            .tag(2)
                    }
                    
                    .accentColor(Color(red: 79/255, green: 143/255, blue: 0/255))
                    
                    
                }
            }
            .navigationBarBackButtonHidden(true)
        }
    }
}


#Preview{
    ContentView()
}
//import SwiftUI
//
//struct ContentView: View {
//    @State private var showSplash = true  // Splash screen toggle
//    @State private var selection = 0  // Tab selection state
//    @State private var isSheetVisible = false
//    @State private var userName: String = "Aditya Gaba"
//    
//    var body: some View {
//        ZStack {
//            if showSplash {
//                // Splash Screen
//                SplashScreenView(isActive: $showSplash)
//                    .transition(.opacity)
//            } else {
//                // Main Content
//                mainContent
//                    .transition(.move(edge: .bottom))
//            }
//        }
//        .onAppear {
//            // Delay for splash screen
//            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
//                withAnimation {
//                    showSplash = false
//                }
//            }
//        }
//    }
//    
//    // Main Content after splash screen
//    private var mainContent: some View {
//        GeometryReader { geometry in
//            NavigationView {
//                VStack {
//                    // ScrollView Content (Artwork)
//                    ScrollView {
//                        VStack {
//                            ArtWork()
//                        }
//                    }
//                    
//                    Spacer()
//                    
//                    // TabView at the bottom
//                    TabView(selection: $selection) {
//                        // Home Tab
//                        HomeView(userName: userName)
//                            .tabItem {
//                                CustomTabItem(imageName: "house.fill", text: "Home")
//                            }
//                            .tag(0)
//                        
//                        // Scanner Tab
//                        BarcodeTextScannerView()
//                            .tabItem {
//                                CustomTabItem(imageName: "barcode.viewfinder", text: "Scanner")
//                            }
//                            .tag(1)
//                        
//                        // Browse Tab
//                        HealthPlannerContentView()
//                            .tabItem {
//                                CustomTabItem(imageName: "square.grid.2x2.fill", text: "Browse")
//                            }
//                            .tag(2)
//                    }
//                    .accentColor(Color(red: 79 / 255, green: 143 / 255, blue: 0 / 255))  // Tab color
//                    .frame(height: geometry.size.height * 0.1)  // Bottom space for TabView
//                    
//                    // Glass Morphism Bottom Bar
//                    BottomBar()
//                        .frame(height: 80)
//                        .offset(y: -geometry.safeAreaInsets.bottom)
//                }
//            }
//        }
//        .navigationBarBackButtonHidden(true)
//    }
//}
//
//struct BottomBar: View {
//    var body: some View {
//        ZStack {
//            Color.clear  // Transparent background
//            
//            VisualEffectView(effect: UIBlurEffect(style: .systemMaterial))  // Blur effect
//                .opacity(0.5)
//            
//            // Gradient for the bar
//            Rectangle()
//                .fill(
//                    LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.3), Color.white.opacity(0.0)]),
//                                   startPoint: .top, endPoint: .bottom)
//                )
//                .frame(height: 120)
//        }
//    }
//}
//
//// Example Splash Screen View
//struct SplashScreenView: View {
//    @Binding var isActive: Bool
//    
//    var body: some View {
//        VStack {
//            // Custom splash screen design
//            Text("Welcome to AllerBite!")
//                .font(.largeTitle)
//                .fontWeight(.bold)
//                .foregroundColor(.green)
//            
//            Spacer()
//            
//            Image(systemName: "leaf.fill")
//                .resizable()
//                .frame(width: 150, height: 150)
//                .foregroundColor(.green)
//            
//            Spacer()
//        }
//        .frame(maxWidth: .infinity, maxHeight: .infinity)
//        .background(Color.white)
//    }
//}
//
//// Example Custom TabItem for TabView
////struct CustomTabItem: View {
////    let imageName: String
////    let text: String
////    
////    var body: some View {
////        VStack {
////            Image(systemName: imageName)
////            Text(text)
////        }
////    }
////}
////
////// Dummy views for Home, Scanner, and Browse
////struct HomeView: View {
////    let userName: String
////    var body: some View {
////        Text("Home View for \(userName)")
////    }
////}
////
////struct BarcodeTextScannerView: View {
////    var body: some View {
////        Text("Barcode Scanner View")
////    }
////}
////
////struct HealthPlannerContentView: View {
////    var body: some View {
////        Text("Health Planner Content View")
////    }
////}
//
//#Preview {
//    ContentView()
//}
